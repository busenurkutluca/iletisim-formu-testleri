import IletisimFormu from './components/IletisimFormu';

const App = () => {
  return (
    <div className="App">
      <IletisimFormu />
    </div>
  );
};

export default App;
